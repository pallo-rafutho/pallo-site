
import './App.css';
import About from './components/about/about'
import Exp from './components/experience/experience'
import Cont from './components/contact/contact'
import logo from './logo.png'


function App() {
  return (
    <div className="App">
      <header className="App-header">
        { <img src={logo} className="App-logo" alt="logo" />}
        
        
      </header>
      <Cont/>
      <About/>
      <Exp/>
      
    </div>
  );
}

export default App;
