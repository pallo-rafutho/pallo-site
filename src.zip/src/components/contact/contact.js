
import React from 'react';
import './contact.css'
import git from './git.png'
import linked from './linked.png'

function Con() {
  return (
    <div className="Con">
      <h1>Pallo Rafutho</h1>
      <h5 className='text-light'>University Graduate</h5>
      <links>
        <a
          
          href="https://github.com/pallo-rafutho"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img src={git} className="git" alt="gitlogo"/> 
        </a>
        <a 
          href="https://www.linkedin.com/in/pallo-rafutho-68626a250/"
          target="_blank"
          rel="noopener noreferrer"
        >
          <img src={linked} className="linked" alt="linklogo"/>
          
        </a>
      </links>
    </div>
  );
}

export default Con;
