
import React from 'react';
import './experience.css'


function Exp() {
  return (
    <div className="Exp">
      <titl>
        MY EXPERIENCE
      </titl>
      
      <expr>
        
        <article>c++: 3 years study</article>
        <article>python: 2 years study</article>
        <article>oracle sql: 1 year study</article>
        <article>javascript: 1 year study</article>
      </expr>

            
    </div>
  );
}

export default Exp;
