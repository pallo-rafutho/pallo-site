
import React from 'react'
import './about.css'
import pallo from './pallo.jpg'

function About() {
  return (
    <div className="About">
          <imag>
            
              <img src={pallo} className="images" alt="pal"/>
            
          </imag>

          <mystory className="aboutme">
          
            <story>
            I am Pallo Tshepang Rafutho, 21 years old, and a final year BSc Computing student at the University of South Africa.
            I was born and raised in Kew, a Johannesburg northern suburb.
            My interests are chess, golf, computer games, and travelling.
            My short term goal is to become a software developer.
            I have learned C++ and Python programing languages at the university. 
            I am looking forward to learning other programming languages. 
            
            I am also willing to work in any type of work environment, in South Africa and abroad. 
            I am available for work from December 2022. 
            My long term goal is to become a senior software engineer.
            </story>

          </mystory>
        
        


    </div>
  );
}

export default About;
